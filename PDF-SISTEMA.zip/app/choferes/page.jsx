import Header from "@/components/Header"
import ChoferesRegistro from "@/components/ChoferesRegistro"

export default function ChoferesPage() {
  return (
    <main>
      <Header />
      <ChoferesRegistro />
    </main>
  )
}

