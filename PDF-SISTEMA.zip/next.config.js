const nextConfig = {
  reactStrictMode: true,
}

module.exports = nextConfig

